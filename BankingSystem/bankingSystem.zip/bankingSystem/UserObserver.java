public interface UserObserver {
    void update(String loanType, double interestRate);
}
